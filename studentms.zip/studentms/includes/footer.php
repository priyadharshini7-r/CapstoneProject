
<div class="footer">
    
    <div class="container">
      <div class="col-md-6 footer-left">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="admin/login.php">Admin</a></li>
          <li><a href="user/login.php">Student</a></li>
        </ul>
       
      </div>
      <div class="col-md-3 footer-middle">
        <?php
$sql="SELECT * from tblpage where PageType='contactus'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
        <h3>Address</h3>
        <div class="address">
          <p><?php  echo htmlentities($row->PageDescription);?>
          </p>
        </div>
        <div class="phone">
          <p><?php  echo htmlentities($row->MobileNumber);?></p>
        </div>
      <?php $cnt=$cnt+1;}} ?></div>
      <div class="col-md-3 footer-right">
        <h3>Techmint</h3>
        <p>Teachmint is leading multinational corporation and creator of the Integrated School Platform (ISP) with over 15 million users in 25+ countries. Available in 20+ languages, the ISP is a school operating system empowering all stakeholders. </p>
      </div>
      <div class="clearfix"> </div> 
    </div>
    
  </div>


<div class="copyright">
    
    <div class="container">
      <div class="copyright-left">
      <p>© <?php echo date('Y');?> Student Management System </p>
      </div>
      <div class="copyright-right">
        <ul>
          <li><a href="https://twitter.com/tecmint?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="twitter"> </a></li>
          <li><a href="https://www.facebook.com/groups/LinuxSysAdmins/" class="twitter facebook"> </a></li>
          <li><a href="https://www.tecmint.com/" class="twitter chrome"> </a></li>
          <li><a href="https://in.pinterest.com/tecmint/" class="twitter pinterest"> </a></li>
          <li><a href="https://www.linkedin.com/company/teachmint/?originalSubdomain=fr" class="twitter linkedin"> </a></li>
          <li><a href="https://twitter.com/tecmint?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="twitter dribbble"> </a></li>
        </ul>
      </div>
      <div class="clearfix"> </div>
      
    </div>
 <script type="text/javascript">
    $(document).ready(function() {
    $().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

  </div>